<script src="{{asset('assets/JS/owl.carousel.min.js')}}"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="{{asset('assets/JS/jquery.validate.min.js')}}"></script>


@yield('footer_library_js')


@yield('footer_custom_js')
