 

<?php $__env->startSection('seo_title', 'Login'); ?>



<?php $__env->startSection('body_content'); ?>

	<div class="main-panel">

		<div class="content-wrapper">
			 <div class="col-lg-12 grid-margin stretch-card table-responsive">
                <div class="card" style = "overflow-x:auto;">
                  <div class="card-body">
                    <h4 class="card-title">Patient List</h4>
                    <!-- <p class="card-description"> Add class <code>.table-hover</code> -->
                    </p>
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <!-- <th>Patient Id</th> -->
                          <th>Email</th>
                          <th>Name</th>
                          <!-- <th>Age</th> -->
                          <th>Mobile</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php foreach($patients_list as $patient) { ?>
                        <tr>
                          
                          <td><?php echo e($patient['email']); ?></td>
                          <td><?php echo e(ucfirst($patient['name'])); ?></td>
                          
                          <td><?php echo e($patient['mobile']); ?></td>
                          <td><label class="badge badge-success show-patient-details" data-patient = "<?php echo e($patient['patient_id']); ?>" data-email = "<?php echo e($patient['email']); ?>" data-name = "<?php echo e(ucfirst($patient['name'])); ?>" data-age = "<?php echo e($patient['age']); ?>" data-mobile = "<?php echo e($patient['mobile']); ?>" data-gender = "<?php echo e($patient['Gender']); ?>" data-created = "<?php echo e(date('jS \of F Y',strtotime($patient['created_at']))); ?>">View</label>&nbsp;<a href = "<?php echo e(url('hospital/patient/update/'.$patient['id'])); ?>"><label class="badge badge-success">Edit</label></a></td>
                        </tr>
                    <?php } ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
		</div>


		<?php echo $__env->make('layouts.blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_custom_js'); ?>
<script type="text/javascript">
	$('table').dataTable();


</script>
<script type="text/javascript">
  $('.show-patient-details').click(function(){

    $('#patient_id').text($(this).attr('data-patient'))
    $('#patient_name').text($(this).attr('data-name'))
    $('#patient_email').text($(this).attr('data-email'))
    $('#patient_age').text($(this).attr('data-age'))
    $('#patient_mobile').text($(this).attr('data-mobile'))
    if($(this).attr('data-gender') == 'M'){
      $('#patient_gender').text("Male")
    }
    if($(this).attr('data-gender') == 'F'){
      $('#patient_gender').text("Female")
    }
    if($(this).attr('data-gender') == 'O'){
      $('#patient_gender').text("Other")
    }
    $('#patient_created').text($(this).attr('data-created'))
    

    $('#patient_details').modal('show');
  })

  $('.cancel').click(function(){
    $('#patient_details').modal('hide');
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback-system\resources\views/hospital/patient/list.blade.php ENDPATH**/ ?>