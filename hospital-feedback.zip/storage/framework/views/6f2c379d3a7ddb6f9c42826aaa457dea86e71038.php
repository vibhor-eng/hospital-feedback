<?php //dd($errors); ?>
<?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible mt-1">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> -->
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback-system\resources\views/layouts/blocks/error.blade.php ENDPATH**/ ?>