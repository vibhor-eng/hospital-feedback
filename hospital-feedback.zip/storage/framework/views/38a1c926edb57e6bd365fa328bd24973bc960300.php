<?php if(\Session::has('success')): ?>
            <div class="alert alert-success mt-1">
                <ul>
                    <li><?php echo \Session::get('success'); ?></li>
                </ul>
            </div>
        <?php endif; ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback\resources\views/layouts/blocks/success.blade.php ENDPATH**/ ?>