 

<?php $__env->startSection('seo_title', 'Login'); ?>



<?php $__env->startSection('body_content'); ?>


	<div class="main-panel">

		<div class="content-wrapper">
			 <div class="col-lg-12 grid-margin stretch-card table-responsive">
                <div class="card" style = "overflow-x:auto;">
                  <div class="card-body">
                    <h4 class="card-title">Patient Queries</h4>
                    <!-- <p class="card-description"> Add class <code>.table-hover</code> -->
                    </p>
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <!-- <th>Patient Id</th> -->
                          <th>Image</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Mobile</th>
                          <th>Message</th>
                          <th>Department</th>
                          <th>Admin Reply</th>
                          <!-- <th>Reply</th> -->
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $query_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          
                          <td>
                            <?php if($query->image): ?>
                              <img src="<?php echo e(asset('storage/' . $query->image)); ?>" alt="Uploaded Image" width="300">
                            <?php else: ?>
                              -
                            <?php endif; ?>
                          </td>
                          <td><?php echo e(ucfirst($query->name)); ?></td>
                          <td><?php echo e($query->email); ?></td>
                          <td><?php echo e($query->mobile); ?></td>
                          <td><?php echo e($query->message); ?> <?php echo e($query->query_type_id); ?></td>
                          <td>
                            <select class="form-select" name = "query_type_sel" class = "query_type_sel" style="width: 150px;" onchange="updateDepartment('<?php echo e($query->id); ?>',this)">
                              <option value="">Please select</option>
                              <?php $__currentLoopData = $query_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($types['id']); ?>" 
                                <?php if($query->query_type_id == $types['id']): ?>
                                  selected = 'selected' 
                                <?php endif; ?>
                                ><?php echo e($types['name']); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </td>
                          <td><?php echo e(!empty($query->message_reply_by_admin) ? $query->message_reply_by_admin : '-'); ?></td>
                          
                          <?php if($query->is_reply == 'no'): ?>
                          <td><label class="badge badge-danger give-reply" data-id = "<?php echo e($query->id); ?>" data-mob = "<?php echo e($query->mobile); ?>" data-msg = "<?php echo e($query->message); ?>">Pending</label></td>
                          <?php else: ?>
                          <td><label class="badge badge-success">Replied</label></td>
                          <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
		</div>


		<?php echo $__env->make('layouts.blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_custom_js'); ?>
<script type="text/javascript">
 $('.give-reply').click(function(){

  $('#patient_reply').modal('show');
  $('#id').val($(this).attr('data-id'));
  $('#mob').val($(this).attr('data-mob'));
  $("textarea#patient_msg").val($(this).attr('data-msg'));
  $('#patient_msg').prop('disabled', true);

   });

  $('#reply_by_admin').click(function(e){

    let id = $('#id').val();
    let message = $('#message').val();
    let query_type_id = $('#query_type').val();
    let mob = $('#mob').val();

    if(message == ''){
      alert("Please enter message");
      return false;
    }

    if(query_type_id == ''){
      alert("Please select query type");
      return false;
    }


  $.ajax({
         url: "<?php echo e(url('hospital/reply')); ?>",
         type: "POST",
         data:{
          id:id,message:message,query_type_id:query_type_id,mob:mob
         },
         dataType: 'json',
         beforeSend: function(){
          // $('#invite-agent').attr('disabled','disabled');
          // $('#invite-agent').hide();
          // $('.fa-spin').css('font-size','24px');
          // $('.fa-spin').show();
         },
         success: function (data) {
          $('#patient_reply').modal('hide');
            if(data.status == true){



            swal({
              title: 'Success',
              text: 'Reply has been sent.',
              type: 'success',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          },
           function(isConfirm) {
                if (isConfirm) {
                   location.reload();
                }
           });
               

             

            }else{
            
              swal({
              title: 'Oops..',
              text: 'Something went wrong!',
              type: 'error',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          });

            }
         },
         error: function (jqXHR, textStatus, errorThrown) {
          $('#patient_reply').modal('hide');
             if (jqXHR.status == 500) {


        swal({
              title: 'Oops..',
              text: "Something went wromg.",
              type: 'error',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          });

                
             } else {
                 console.log(jqXHR.responseText);
             }
         }
     });

  });
 




 $('.cancel').click(function(){

  $('#patient_reply').modal('hide');


 });

function updateDepartment(feedback_id,el){

  let dept_id = el.value

  $.ajax({
         url: "<?php echo e(url('hospital/update-dept')); ?>",
         type: "POST",
         data:{
          feedback_id:feedback_id,dept_id:dept_id
         },
         dataType: 'json',
         beforeSend: function(){
         },
         success: function (data) {
         
            if(data.status == true){



            swal({
              title: 'Success',
              text: data.msg,
              type: 'success',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          },
           function(isConfirm) {
                if (isConfirm) {
                   location.reload();
                }
           });
               

             

            }else{
            
              swal({
              title: 'Oops..',
              text: 'Something went wrong!',
              type: 'error',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          });

            }
         },
         error: function (jqXHR, textStatus, errorThrown) {
             if (jqXHR.status == 500) {


        swal({
              title: 'Oops..',
              text: "Something went wromg.",
              type: 'error',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          });

                
             } else {
                 console.log(jqXHR.responseText);
             }
         }
     });

}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback-system\resources\views/hospital/patient_query/list.blade.php ENDPATH**/ ?>