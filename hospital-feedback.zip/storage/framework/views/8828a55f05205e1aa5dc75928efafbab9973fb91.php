 

<?php $__env->startSection('seo_title', 'Login'); ?>



<?php $__env->startSection('body_content'); ?>

<!-- partial -->
        <div class="main-panel">
        	
	          <div class="content-wrapper">
	            
	         <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  	<?php echo $__env->make('layouts.blocks.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                	<?php echo $__env->make('layouts.blocks.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <h4 class="card-title">Reset Password For Patient</h4>
                    <form class="forms-sample" id = "reset-password" action = "<?php echo e(route('hospital.reset-password')); ?>" method = "post">
                    	<?php echo csrf_field(); ?>
                      
                    <div class="form-group">
                        <label for="exampleInputPassword4">Password</label>
                        <input type="email" name = "email" class="form-control" id="email" placeholder="Email">
                      </div>

                      <div class="form-group">
                        <label for="exampleInputPassword4">Password</label>
                        <input type="password" name = "password" class="form-control" id="password" placeholder="Password">
                      </div>

                      <div class="form-group">
                        <label for="exampleInputPassword4">Confirm Password</label>
                        <input type="password" name = "confirm_password" class="form-control" id="confirm_password" placeholder="Password">
                      </div>
                      
                      
                      
                      <button type="submit" class="btn btn-gradient-primary me-2">Submit</button>
                    </form>
                  </div>
                </div>
              </div>

	          </div>
	          
	          <?php echo $__env->make('layouts.blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
        </div>
        

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_custom_js'); ?>

  <script type="text/javascript">
    
    $(document).ready(function () {


      $('#reset-password').validate({ // initialize the plugin
          rules: {
              email: {
                  required: true,
                  email: true,
              },
              password:{
                required:true,
                minlength:6,
                maxlength:8,
              },
              confirm_password: {
                required: true,
                equalTo: "#password",  // Use the custom method for password confirmation
              },
          },
          submitHandler: function(form) {
            form.submit(); // Submit the form if valid
          }
      });

  });

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback-system\resources\views/hospital/reset-password.blade.php ENDPATH**/ ?>