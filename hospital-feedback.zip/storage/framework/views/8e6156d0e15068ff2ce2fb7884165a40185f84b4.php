<!DOCTYPE html>
   <!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
   <!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
   <!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
   <!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->

   <head>
    <title> Hospital Feedback Management </title>

      
      <?php if(Auth::check()): ?>
        <?php echo $__env->make('layouts.blocks.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php else: ?>
        <?php echo $__env->make('layouts.blocks.login_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>

       <?php echo $__env->yieldContent('header_custom_css'); ?>

      <?php echo $__env->yieldContent('header_custom_js'); ?>

   </head>

   <body>
  
    <?php if(Auth::check()): ?> 
     <?php echo $__env->make('layouts.blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="container-fluid page-body-wrapper">
      <?php echo $__env->make('layouts.blocks.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

      


      <?php echo $__env->yieldContent('body_content'); ?>

      <?php if(Auth::check()): ?> 
      <?php echo $__env->make('layouts.blocks.modal-contents', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
      <?php endif; ?>



      <?php echo $__env->yieldContent('footer_custom_js'); ?>



   </body>
</html>
<?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback\resources\views/layouts/master.blade.php ENDPATH**/ ?>