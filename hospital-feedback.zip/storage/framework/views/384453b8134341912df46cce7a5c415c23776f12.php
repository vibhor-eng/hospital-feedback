 

<?php $__env->startSection('seo_title', 'Login'); ?>



<?php $__env->startSection('body_content'); ?>

<!-- partial -->
        <div class="main-panel">
        	
	          <div class="content-wrapper">
	            
	         <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  	<?php echo $__env->make('layouts.blocks.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                	<?php echo $__env->make('layouts.blocks.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <h4 class="card-title">Update Patient Details</h4>
                    <form class="forms-sample" id = "update-patient" action = "<?php echo e(route('hospital.patient.update')); ?>" method = "post">
                    	<?php echo csrf_field(); ?>

                      
                        
                        <input type = "hidden" name = "id" value = "<?php echo e($patient_details['id']); ?>">

                        <div class="form-group">
                            <div class = "row">
                              <div class = "col-md-6">
                                <label for="exampleInputPassword4">Email</label>
                                <input type="email" name = "email" class="form-control" id="email" placeholder="Email" value = "<?php echo e($patient_details['email']); ?>">
                              </div>

                              <div class = "col-md-6">
                                <label for="exampleInputPassword4">Name</label>
                                <input type="test" name = "name" class="form-control" id="name"  placeholder="Name" value = "<?php echo e($patient_details['name']); ?>">
                              </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class = "row">
                              <div class = "col-md-6">
                                <label for="exampleInputPassword4">Age</label>
                                <input type="text" name = "age" class="form-control" id="age"  placeholder="Age" value = "<?php echo e($patient_details['age']); ?>">
                              </div>

                              <div class = "col-md-6">
                                <label for="exampleInputPassword4">Mobile</label>
                                <input type="text" name = "mobile" class="form-control" id="mobile" placeholder="Mobile" value = "<?php echo e($patient_details['mobile']); ?>">
                              </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class = "row">
                              <div class = "col-md-6">
                                <label for="exampleInputPassword4">Gender</label>
                                <select class="form-select" name = "gender" id="exampleFormControlSelect2">
                                  <option value = "">--Select Gender--</option>
                                  <option value = "M" <?php if($patient_details['Gender'] == 'M'): ?> selected = 'selected' <?php endif; ?>>Male</option>
                                  <option value = "F" <?php if($patient_details['Gender'] == 'F'): ?> selected = 'selected' <?php endif; ?>>Female</option>
                                  <option value = "O" <?php if($patient_details['Gender'] == 'O'): ?> selected = 'selected' <?php endif; ?>>Other</option>
                                </select>
                              </div>
                            </div>
                        </div>

                      
                      <button type="submit" class="btn btn-gradient-primary me-2">Submit</button>
                    </form>
                  </div>
                </div>
              </div>

	          </div>
	          
	          <?php echo $__env->make('layouts.blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
        </div>
        

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_custom_js'); ?>

  <script type="text/javascript">
    
    $(document).ready(function () {


      $('#reset-password').validate({ // initialize the plugin
          rules: {
              email: {
                  required: true,
                  email: true,
              },
              password:{
                required:true,
                minlength:6,
                maxlength:8,
              },
              confirm_password: {
                required: true,
                equalTo: "#password",  // Use the custom method for password confirmation
              },
          },
          submitHandler: function(form) {
            form.submit(); // Submit the form if valid
          }
      });

  });

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback-system\resources\views/hospital/patient/edit.blade.php ENDPATH**/ ?>