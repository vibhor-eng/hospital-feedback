 

<?php $__env->startSection('seo_title', 'Login'); ?>



<?php $__env->startSection('body_content'); ?>

<!-- partial -->
        <div class="main-panel">
        	<?php echo $__env->make('layouts.blocks.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	          <div class="content-wrapper">

	          	<h1>Generated QR Code</h1>
   			<?php echo $qrCode; ?>

	            
	          </div>
	          
	          <?php echo $__env->make('layouts.blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
        </div>
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback\resources\views/patient/dashboard.blade.php ENDPATH**/ ?>