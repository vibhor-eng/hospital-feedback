 

<?php $__env->startSection('seo_title', 'Login'); ?>

<?php $__env->startSection('header_custom_css'); ?>
<style>
    body{
    background: #f2edf3;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_content'); ?>
    
<div class="main-panel" style="margin:auto; float: none;">
          <div class="content-wrapper">
            <div class="row">
              
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h2 class="text-center">Patient Login</h2>
                    
                    <form class="forms-sample">
                      
                      <div class="form-group">
                        <label for="exampleInputEmail3">Email address</label>
                        <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Email">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword4">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Password">
                      </div>
                      
                      <button type="submit" class="btn btn-gradient-primary me-2">Login</button>
                      <button type="submit" class="btn btn-gradient-primary me-2">Register</button>
                    </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2024 All rights reserved.</span>
            </div>
          </footer>
          <!-- partial -->
        </div>

  <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback-system\resources\views/auth/user-login.blade.php ENDPATH**/ ?>