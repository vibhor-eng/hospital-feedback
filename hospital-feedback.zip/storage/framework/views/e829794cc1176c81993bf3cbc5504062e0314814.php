 

<?php $__env->startSection('seo_title', 'Login'); ?>



<?php $__env->startSection('body_content'); ?>

	<div class="main-panel">

		<div class="content-wrapper">
			 <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Department List</h4>
                    <!-- <p class="card-description"> Add class <code>.table-hover</code> -->
                    </p>
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Id</th>
                          <th>Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php foreach($department_list as $key => $department) { ?>
                        <tr>
                          <td><?php echo e($key+1); ?></td>
                          <td><?php echo e($department['name']); ?></td>
                          <td><label class="badge badge-success create-dept">Create</label>&nbsp;<label class="badge badge-danger">Delete</label>&nbsp;<label class="badge badge-primary">Edit</label></td>
                        </tr>
                    <?php } ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
		</div>


		<?php echo $__env->make('layouts.blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_custom_js'); ?>
<script type="text/javascript">
	$('table').dataTable();

    $('.create-dept').click(function(){
     $('#add_department').modal('show');  
   });


  $('#save_department').click(function(){

    
    let name = $('#name').val();

    if(name == ''){
      alert("Please enter name");
      return false;
    }


  $.ajax({
         url: "<?php echo e(url('hospital/department/create')); ?>",
         type: "POST",
         data:{
         name:name
         },
         dataType: 'json',
         beforeSend: function(){
          // $('#invite-agent').attr('disabled','disabled');
          // $('#invite-agent').hide();
          // $('.fa-spin').css('font-size','24px');
          // $('.fa-spin').show();
         },
         success: function (data) {
          $('#add_department').modal('hide');
            if(data.status == true){



            swal({
              title: 'Success',
              text: 'Reply has been sent.',
              type: 'success',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          },
           function(isConfirm) {
                if (isConfirm) {
                   location.reload();
                }
           });
               

             

            }else{
            
              swal({
              title: 'Oops..',
              text: 'Something went wrong!',
              type: 'error',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          });

            }
         },
         error: function (jqXHR, textStatus, errorThrown) {
          $('#add_department').modal('hide');
             if (jqXHR.status == 500) {


        swal({
              title: 'Oops..',
              text: "Something went wromg.",
              type: 'error',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          });

                
             } else {
                 console.log(jqXHR.responseText);
             }
         }
     });

  });

$('.cancel').click(function(){

  $('#add_department').modal('hide');


 });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vibhor\hospital-feedback-system\resources\views/hospital/department/list.blade.php ENDPATH**/ ?>